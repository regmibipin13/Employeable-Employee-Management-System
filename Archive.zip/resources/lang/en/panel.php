<?php

return [
    'site_title' => 'EMS',
];
